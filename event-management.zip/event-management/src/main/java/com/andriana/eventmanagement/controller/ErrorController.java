package com.andriana.eventmanagement.controller;

public class ErrorController {
}
